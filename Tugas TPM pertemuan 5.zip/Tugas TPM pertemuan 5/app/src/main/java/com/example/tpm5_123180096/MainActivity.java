package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import static com.example.myapplication3.KlubAdapter.*;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvKlub;
    private ArrayList<KlubModel> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvKlub = findViewById(R.id.activitymain_rv);
        rvKlub.setHasFixedSize(true);
        list.addAll(Dataklub.getHeroList());

        showRecyclerList();
    }
    private  void showRecyclerList(){
        rvKlub.setLayoutManager(new LinearLayoutManager(this));
        KlubAdapter klubAdapter = new KlubAdapter(this);
        klubAdapter.setListKlub(list);
        rvKlub.setAdapter(klubAdapter);

    }
}