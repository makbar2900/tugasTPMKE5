package com.example.myapplication3;

import java.util.ArrayList;

public class Dataklub {
    private static String[] namaklub = new String[] {
            "Istanbul Basaksehir",
            "Akhisar Belediyespor",
            "Alanyaspor",
            "Antalyaspor",
            "Besiktas Jk",
            "Bursaspor",
            "Genclerbirligi",
            "Kasimpasa",
            "Konyaspor",
            "Trabzonspor",
    };

    private static String[] Detailklub = new String[] {
            "İstanbul Başakşehir Futbol Kulübü, yang awalnya disebut İstanbul Büyükşehir Belediyespor atau pendeknya Istanbul BB, adalah sebuah klub sepak bola Turki. Mereka bermain permainan kandang mereka di Stadion Başakşehir Fatih Terim di Istanbul dan dimiliki oleh Munisipalitas Istanbul.",
            "Akhisar belediyespor adalah klub berasal dari turki.",
            "Alanyaspor adalah klub sepak bola profesional Turki yang berbasis di Alanya. Berdiri pada tahun 1948, klub ini memainkan partai kandang di Bahçeşehir Okulları Stadium",
            "Antalyaspor adalah klub sepak bola profesional Turki yang berbasis di Antalya. Mereka memainkan partai kandang di Antalya Arena dan menggunakan warna seragam merah dan putih. Antalyaspor telah menjuarai First League sebanyak dua kali pada tahun 1982 dan 1986, serta menjadi runner up Turkish Cup tahun 2000",
            "Besiktas Jimnastik Kulübü adalah sebuah klub olahraga Turki. Tim sepak bola klub ini adalah salah satu tim terbesar di Turki. Klub olahraga profesional didirikan pada tahun 1903 di distrik Besiktas di Istanbul, Turki. Klub ini adalah klub olahraga pertama di Turki",
            "Bursaspor Kulübü Derneği commonly known as Bursaspor, is a Turkish sports club located in the city of Bursa. ",
            "Gençlerbirliği Spor Kulübü atau Gençlerbirliği adalah klub sepak bola profesional Turki yang berbasis di Ankara.",
            "Kasımpaşa S.K. atau Kasımpaşa SK atau Kasımpaşa adalah klub sepak bola profesional Turki yang berbasis di distrik Beyoğlu kota Istanbul.",
            "Konyaspor Kulübü is a Turkish professional football club based in Konya.",
            "Trabzonspor is a Turkish sports club located in the city of Trabzon.",

    };

    private static int[] fotoklub = new int[]{
            R.drawable.istanbulbbsk,
            R.drawable.alanyasporsportsklub,
            R.drawable.konyasporsportsklub,
            R.drawable.genclerbirligi,
            R.drawable.trabzonsporsportsklub,
            R.drawable.besiktas,
            R.drawable.besiktas,
            R.drawable.bursasporsportsklub,
            R.drawable.akhisar,
            R.drawable.kasimpasa
    };

    public static ArrayList<KlubModel> getHeroList(){
        KlubModel KlubModel = null;
        ArrayList<KlubModel> list = new ArrayList<>();

        for (int i = 0; i < namaklub.length; i++){
            KlubModel = new KlubModel();
            KlubModel.setNama(namaklub[i]);
            KlubModel.setDetail(Detailklub[i]);
            KlubModel.setFotoklub(fotoklub[i]);

            list.add(KlubModel);
        }
        return list;
    }

}
