package com.example.myapplication3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.time.Instant;
import java.util.ArrayList;

public class KlubAdapter extends RecyclerView.Adapter<KlubAdapter.ViewHolder> {

    private ArrayList<KlubModel> listKlub;
    private Context context;


    public KlubAdapter (Context context) {
        this.context = context;
    }

    public ArrayList<KlubModel> getListKlub() {
        return listKlub;
    }

    public void setListKlub(ArrayList<KlubModel> listKlub) {
        this.listKlub = listKlub;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemrow = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_klub, parent, false);
        return new ViewHolder(itemrow);
    }

    @Override
    public void onBindViewHolder(@NonNull KlubAdapter.ViewHolder viewHolder, final int i) {
        Glide.with(context).load(getListKlub().get(i).getFoto()).into(viewHolder.ivKlub);
        viewHolder.tvNama.setText(getListKlub().get(i).getNama());
        viewHolder.btnLihat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Detailklub.class);

                intent.putExtra("img_url", getListKlub().get(i).getFoto());
                intent.putExtra("name",getListKlub().get(i).getNama());
                intent.putExtra("detail", getListKlub().get(i).getDetail());
                context.startActivity(intent);
            }
        });

        viewHolder.btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                String namaklub = "nama klub ini adalah " + getListKlub().get(i).getDetail();
                intent.putExtra(Intent.EXTRA_TEXT, namaklub);
                context.startActivity(Intent.createChooser(intent, "Share Using"));
            }
        });

    }

    @Override
    public int getItemCount() {
        return getListKlub().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivKlub;
        TextView tvNama;
        Button btnShare, btnLihat;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivKlub = itemView.findViewById(R.id.item_iv);
            tvNama = itemView.findViewById(R.id.nama_tv);
            btnLihat = itemView.findViewById(R.id.lihat_btn);
            btnShare = itemView.findViewById(R.id.share_btn);
        }
    }
}
