package com.example.recycleview173;

public class FragmentKlub {
}
