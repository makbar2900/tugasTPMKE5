package com.example.myapplication3;

public class KlubModel {
    private String namaKlub;
    private String detailKlub;
    private int fotoKlub;

    public String getNama() {
        return namaKlub;
    }

    public void setNama(String nama) {

        this.namaKlub = nama;
    }

    public String getDetail() {
        return detailKlub;
    }

    public void setDetail(String detail) {
        this.detailKlub = detail;
    }

    public int getFoto() {
        return fotoKlub;
    }

    public void setFotoklub(int fotoklub) {
        this.fotoKlub = fotoKlub;
    }
}